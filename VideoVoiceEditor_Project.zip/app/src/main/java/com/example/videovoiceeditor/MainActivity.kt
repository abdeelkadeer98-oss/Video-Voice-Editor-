package com.example.videovoiceeditor

import android.Manifest
import android.content.ContentValues
import android.content.Intent
import android.content.pm.PackageManager
import android.media.MediaRecorder
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.os.Handler
import android.os.Looper
import android.provider.MediaStore
import android.view.View
import android.widget.Button
import android.widget.ProgressBar
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.common.util.UnstableApi
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.transformer.Composition
import androidx.media3.transformer.EditedMediaItem
import androidx.media3.transformer.EditedMediaItemSequence
import androidx.media3.transformer.ExportException
import androidx.media3.transformer.ExportResult
import androidx.media3.transformer.ProgressHolder
import androidx.media3.transformer.Transformer
import androidx.media3.ui.PlayerView
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.util.Locale

@OptIn(UnstableApi::class)
class MainActivity : AppCompatActivity() {

    private lateinit var player: ExoPlayer
    private lateinit var playerView: PlayerView
    private lateinit var startSeek: SeekBar
    private lateinit var endSeek: SeekBar
    private lateinit var timeLabel: TextView
    private lateinit var status: TextView
    private lateinit var progress: ProgressBar
    private lateinit var exportButton: Button
    private lateinit var recordButton: Button

    private var videoUri: Uri? = null
    private var durationMs = 0L
    private var startMs = 0L
    private var endMs = 0L

    private var recorder: MediaRecorder? = null
    private var voiceFile: File? = null
    private var isRecording = false
    private var isExporting = false
    private var transformer: Transformer? = null
    private var outputTempFile: File? = null

    private val handler = Handler(Looper.getMainLooper())
    private val stopRecordingRunnable = Runnable { stopRecording(autoStopped = true) }
    private val stopPreviewRunnable = Runnable {
        player.pause()
        player.volume = 1f
        status.text = "انتهت معاينة الجزء المحدد."
    }

    private val pickVideo = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri == null) return@registerForActivityResult
        try {
            contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
        } catch (_: Exception) {
            // Some providers don't support persistable permissions; the current URI can still be used.
        }
        videoUri = uri
        player.stop()
        player.clearMediaItems()
        player.setMediaItem(MediaItem.fromUri(uri))
        player.prepare()
        status.text = "جارٍ تحميل الفيديو..."
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        playerView = findViewById(R.id.playerView)
        startSeek = findViewById(R.id.startSeek)
        endSeek = findViewById(R.id.endSeek)
        timeLabel = findViewById(R.id.timeLabel)
        status = findViewById(R.id.statusText)
        progress = findViewById(R.id.progressBar)
        exportButton = findViewById(R.id.exportButton)
        recordButton = findViewById(R.id.recordButton)

        player = ExoPlayer.Builder(this).build()
        playerView.player = player
        player.addListener(object : Player.Listener {
            override fun onPlaybackStateChanged(state: Int) {
                if (state == Player.STATE_READY) {
                    durationMs = player.duration.coerceAtLeast(0L)
                    startMs = 0L
                    endMs = durationMs
                    startSeek.progress = 0
                    endSeek.progress = 1000
                    updateTimeLabel()
                    status.text = "تم تحميل الفيديو. حدد الجزء الذي تريد استبدال صوته."
                }
            }
        })

        findViewById<Button>(R.id.selectVideoButton).setOnClickListener {
            pickVideo.launch(arrayOf("video/*"))
        }

        startSeek.setOnSeekBarChangeListener(seekListener(true))
        endSeek.setOnSeekBarChangeListener(seekListener(false))

        findViewById<Button>(R.id.muteButton).setOnClickListener {
            if (!hasVideo()) return@setOnClickListener
            status.text = "🔇 عند التصدير سيتم كتم الصوت الأصلي من ${fmt(startMs)} إلى ${fmt(endMs)}."
        }

        recordButton.setOnClickListener { startRecording() }
        findViewById<Button>(R.id.stopRecordButton).setOnClickListener { stopRecording() }

        findViewById<Button>(R.id.previewButton).setOnClickListener {
            if (!hasVideo()) return@setOnClickListener
            val length = endMs - startMs
            if (length < 300) {
                status.text = "اختر جزءًا أطول من نصف ثانية."
                return@setOnClickListener
            }
            handler.removeCallbacks(stopPreviewRunnable)
            player.volume = 1f
            player.seekTo(startMs)
            player.play()
            handler.postDelayed(stopPreviewRunnable, length)
            status.text = "▶️ معاينة الجزء المحدد..."
        }

        exportButton.setOnClickListener { exportVideo() }
    }

    private fun seekListener(isStart: Boolean) = object : SeekBar.OnSeekBarChangeListener {
        override fun onProgressChanged(seekBar: SeekBar?, value: Int, fromUser: Boolean) {
            if (!fromUser || durationMs <= 0) return
            val ms = durationMs * value / 1000L
            if (isStart) {
                startMs = ms.coerceAtMost((endMs - 100).coerceAtLeast(0))
            } else {
                endMs = ms.coerceAtLeast((startMs + 100).coerceAtMost(durationMs))
            }
            updateTimeLabel()
        }
        override fun onStartTrackingTouch(seekBar: SeekBar?) {}
        override fun onStopTrackingTouch(seekBar: SeekBar?) {}
    }

    private fun updateTimeLabel() {
        timeLabel.text = "الجزء المحدد: ${fmt(startMs)} - ${fmt(endMs)}  (${fmt(endMs - startMs)})"
    }

    private fun fmt(ms: Long): String {
        val total = (ms / 1000).coerceAtLeast(0)
        return String.format(Locale.US, "%02d:%02d", total / 60, total % 60)
    }

    private fun hasVideo(): Boolean {
        if (videoUri == null || durationMs <= 0) {
            status.text = "اختر فيديو أولاً."
            return false
        }
        return true
    }

    private fun startRecording() {
        if (!hasVideo()) return
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), 501)
            status.text = "اسمح للتطبيق باستخدام الميكروفون ثم اضغط تسجيل مرة أخرى."
            return
        }
        if (isRecording || isExporting) return

        val selectedDuration = endMs - startMs
        if (selectedDuration < 700) {
            status.text = "اختر جزءًا أطول من ثانية تقريبًا للتسجيل."
            return
        }

        voiceFile = File(cacheDir, "voice_${System.currentTimeMillis()}.m4a")
        try {
            recorder = MediaRecorder(this).apply {
                setAudioSource(MediaRecorder.AudioSource.MIC)
                setOutputFormat(MediaRecorder.OutputFormat.MPEG_4)
                setAudioEncoder(MediaRecorder.AudioEncoder.AAC)
                setAudioEncodingBitRate(128_000)
                setAudioSamplingRate(44_100)
                setOutputFile(voiceFile!!.absolutePath)
                prepare()
                start()
            }
            isRecording = true
            player.volume = 0f
            player.seekTo(startMs)
            player.play()
            recordButton.isEnabled = false
            status.text = "🔴 سجّل صوتك الآن... سيُوقَف التسجيل تلقائيًا عند نهاية الجزء."
            handler.removeCallbacks(stopRecordingRunnable)
            handler.postDelayed(stopRecordingRunnable, selectedDuration + 250L)
        } catch (e: Exception) {
            releaseRecorder()
            status.text = "تعذر بدء التسجيل: ${e.message ?: "خطأ غير معروف"}"
        }
    }

    private fun stopRecording(autoStopped: Boolean = false) {
        handler.removeCallbacks(stopRecordingRunnable)
        if (!isRecording) {
            if (!autoStopped) status.text = "لا يوجد تسجيل جارٍ."
            return
        }
        try {
            recorder?.stop()
        } catch (_: Exception) {
            voiceFile?.delete()
            voiceFile = null
        } finally {
            releaseRecorder()
        }
        isRecording = false
        player.pause()
        player.volume = 1f
        recordButton.isEnabled = true
        status.text = if (voiceFile?.exists() == true) {
            "✅ تم تسجيل صوتك. يمكنك المعاينة أو تصدير MP4."
        } else {
            "تعذر حفظ التسجيل. حاول مرة أخرى."
        }
    }

    private fun releaseRecorder() {
        try { recorder?.reset() } catch (_: Exception) {}
        try { recorder?.release() } catch (_: Exception) {}
        recorder = null
    }

    private fun exportVideo() {
        if (!hasVideo() || isExporting) return
        val uri = videoUri ?: return
        val selectedDuration = endMs - startMs
        if (selectedDuration < 300) {
            status.text = "اختر جزءًا صالحًا للتعديل."
            return
        }

        val temp = File(cacheDir, "export_${System.currentTimeMillis()}.mp4")
        temp.delete()
        outputTempFile = temp
        isExporting = true
        exportButton.isEnabled = false
        recordButton.isEnabled = false
        progress.visibility = View.VISIBLE
        progress.progress = 0
        status.text = "⏳ جارٍ إنشاء الفيديو النهائي..."

        val videoItems = mutableListOf<EditedMediaItem>()
        if (startMs > 0) videoItems += videoClip(uri, 0, startMs)
        videoItems += videoClip(uri, startMs, endMs)
        if (endMs < durationMs) videoItems += videoClip(uri, endMs, durationMs)
        val videoSequence = EditedMediaItemSequence.withVideoFrom(videoItems)

        val audioBuilder = EditedMediaItemSequence.Builder(setOf(C.TRACK_TYPE_AUDIO))
        if (startMs > 0) audioBuilder.addItem(audioClip(uri, 0, startMs))

        val voice = voiceFile
        if (voice != null && voice.exists()) {
            val voiceItem = MediaItem.Builder()
                .setUri(Uri.fromFile(voice))
                .setClippingConfiguration(
                    MediaItem.ClippingConfiguration.Builder()
                        .setStartPositionMs(0)
                        .setEndPositionMs(selectedDuration)
                        .build()
                )
                .build()
            audioBuilder.addItem(EditedMediaItem.Builder(voiceItem).build())
        } else {
            // No voice: the selected portion becomes silent.
            audioBuilder.addGap(selectedDuration * 1000L)
        }

        if (endMs < durationMs) audioBuilder.addItem(audioClip(uri, endMs, durationMs))
        val audioSequence = audioBuilder.build()

        val composition = Composition.Builder(videoSequence, audioSequence).build()
        val progressHolder = ProgressHolder()

        transformer = Transformer.Builder(this)
            .addListener(object : Transformer.Listener {
                override fun onCompleted(composition: Composition, exportResult: ExportResult) {
                    handler.removeCallbacksAndMessages(null)
                    progress.progress = 100
                    saveExportedVideo(temp)
                }

                override fun onError(
                    composition: Composition,
                    exportResult: ExportResult,
                    exportException: ExportException
                ) {
                    handler.removeCallbacksAndMessages(null)
                    isExporting = false
                    exportButton.isEnabled = true
                    recordButton.isEnabled = true
                    progress.visibility = View.GONE
                    status.text = "❌ فشل التصدير: ${exportException.message ?: "خطأ في معالجة الفيديو"}"
                }
            })
            .build()

        transformer!!.start(composition, temp.absolutePath)
        pollProgress(progressHolder)
    }

    private fun pollProgress(holder: ProgressHolder) {
        if (!isExporting) return
        val t = transformer ?: return
        try {
            if (t.getProgress(holder) == Transformer.PROGRESS_STATE_AVAILABLE) {
                progress.progress = holder.progress
            }
        } catch (_: Exception) { }
        handler.postDelayed({ pollProgress(holder) }, 250L)
    }

    private fun videoClip(uri: Uri, start: Long, end: Long): EditedMediaItem {
        val item = MediaItem.Builder()
            .setUri(uri)
            .setClippingConfiguration(
                MediaItem.ClippingConfiguration.Builder()
                    .setStartPositionMs(start)
                    .setEndPositionMs(end)
                    .build()
            )
            .build()
        return EditedMediaItem.Builder(item).setRemoveAudio(true).build()
    }

    private fun audioClip(uri: Uri, start: Long, end: Long): EditedMediaItem {
        val item = MediaItem.Builder()
            .setUri(uri)
            .setClippingConfiguration(
                MediaItem.ClippingConfiguration.Builder()
                    .setStartPositionMs(start)
                    .setEndPositionMs(end)
                    .build()
            )
            .build()
        return EditedMediaItem.Builder(item).build()
    }

    private fun saveExportedVideo(temp: File) {
        if (!temp.exists() || temp.length() == 0L) {
            isExporting = false
            exportButton.isEnabled = true
            recordButton.isEnabled = true
            progress.visibility = View.GONE
            status.text = "❌ لم يتم إنشاء ملف الفيديو."
            return
        }

        try {
            val name = "VideoVoice_${System.currentTimeMillis()}.mp4"
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                val values = ContentValues().apply {
                    put(MediaStore.Video.Media.DISPLAY_NAME, name)
                    put(MediaStore.Video.Media.MIME_TYPE, "video/mp4")
                    put(MediaStore.Video.Media.RELATIVE_PATH, Environment.DIRECTORY_MOVIES + "/Video Voice Editor")
                    put(MediaStore.Video.Media.IS_PENDING, 1)
                }
                val outUri = contentResolver.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, values)
                    ?: throw IllegalStateException("تعذر إنشاء ملف في المعرض")
                contentResolver.openOutputStream(outUri).use { out ->
                    requireNotNull(out) { "تعذر فتح ملف الإخراج" }
                    FileInputStream(temp).use { input -> input.copyTo(out) }
                }
                values.clear()
                values.put(MediaStore.Video.Media.IS_PENDING, 0)
                contentResolver.update(outUri, values, null, null)
                Toast.makeText(this, "تم حفظ الفيديو في Movies/Video Voice Editor", Toast.LENGTH_LONG).show()
            } else {
                val dir = getExternalFilesDir(Environment.DIRECTORY_MOVIES)
                    ?: throw IllegalStateException("تعذر الوصول إلى مجلد الفيديو")
                val destination = File(dir, name)
                FileInputStream(temp).use { input -> FileOutputStream(destination).use { output -> input.copyTo(output) } }
                Toast.makeText(this, "تم حفظ الفيديو داخل مجلد التطبيق", Toast.LENGTH_LONG).show()
            }
            status.text = "🎉 تم التصدير بنجاح. الفيديو جاهز للمشاركة."
        } catch (e: Exception) {
            status.text = "❌ تم إنشاء الفيديو لكن تعذر حفظه: ${e.message ?: "خطأ"}"
        } finally {
            temp.delete()
            isExporting = false
            exportButton.isEnabled = true
            recordButton.isEnabled = true
            progress.visibility = View.GONE
        }
    }

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        if (isRecording) releaseRecorder()
        transformer?.cancel()
        player.release()
        super.onDestroy()
    }
}
